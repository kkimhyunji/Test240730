package testDao;

import dao.MemberDao;

public class TestDao {
	public static void main(String[] args) throws Exception{
		MemberDao mDao = new MemberDao();
		/*--------------------------SELECT---------------------------------*/
		//System.out.println(mDao.loginCheck("hj", "1234"));	
		/*--------------------------UPDATE---------------------------------*/
		mDao.updatePoint(20, "hj");
		mDao.updateMember("hyunji", "1234", 50000, "hj");
		//dao.accountSettingChangeName("원혜경", 2);	
		/*--------------------------DELETE---------------------------------*/
		//dao4.DeleteServiceTalkRoom(2);
		/*--------------------------INSERT---------------------------------*/
		//mDao.memberJoin("admin", "1234", "관리자");
		System.out.println("성공");
		
	}

}
