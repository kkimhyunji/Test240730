package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.MemberDao;
import dto.MemberDto;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
   private static final long serialVersionUID = 1L;
       

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String id = request.getParameter("id");
      String pw = request.getParameter("pw");

      MemberDao mDao = new MemberDao();
      boolean result = false;
      
      try {
         result = mDao.loginCheck(id, pw);
      } catch(Exception e) {
         e.printStackTrace();
      }
      
       if (result) {
	       // 로그인 성공
	       HttpSession session = request.getSession();
	       session.setAttribute("id", id);
	       if ("admin".equals(id)) {
	           // 관리자 계정일 경우
	           response.sendRedirect("AdminPage.jsp");
	       } else {
	           // 일반 사용자 계정일 경우
	           response.sendRedirect("Main.jsp");
	       }
       } else {
           // 로그인 실패 시 오류 메시지를 JSP로 전달
           request.setAttribute("errorMessage", "아이디/비밀번호를 다시 확인하세요");
           RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
           rd.forward(request, response);
       }
   }

}