package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.MemberDao;
@WebServlet("/JoinServlet")
public class JoinServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");
        String pw = request.getParameter("pw");
        String name = request.getParameter("name");
        
        // MemberDao 객체 생성
        MemberDao memberDao = new MemberDao();
        boolean result = false;
        
        try {
			memberDao.memberJoin(id, pw, name);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
        
        if(result) {	
			RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
			rd.forward(request,response);
		} else {		//Ex.jsp로 이동
			RequestDispatcher rd = request.getRequestDispatcher("Join.jsp");
			rd.forward(request,response);
		}
      
	}

}
