package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.MemberDto;

public class MemberDao {
	Connection getConnection() throws Exception{
		String driver = "oracle.jdbc.driver.OracleDriver"; 	
	 	String url = "jdbc:oracle:thin:@localhost:1521:xe"; 
	 	String dbId = "user0625";
	 	String dbPw = "pass1234";
	 	Class.forName(driver);
	 	Connection conn = DriverManager.getConnection(url, dbId, dbPw);
	 	
	 	return conn;
	}
	// 회원가입 insert 문
	// memberJoin(String) : id, pw, name 값을 받아서  인서트
	// 파라미터  : id, pw, name
	public void memberJoin (String id, String pw, String name) throws Exception{
		Connection conn = getConnection();
		String sql = "INSERT INTO member(id, pw, name)"
					+ " VALUES (?, ?, ?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, pw);
		pstmt.setString(3, name);
		pstmt.executeUpdate();
		pstmt.close();
		conn.close();
	}
	// 로그인
	// loginCheck(int) : id, pw 값을 받아서  1의 값를 리턴.
	// 파라미터 id, pw : id, pw
	// 리턴 : 성공시 1의 값을 리턴
	public boolean loginCheck(String id, String pw) throws Exception{
		Connection conn = getConnection();
		String sql = "SELECT COUNT(*) FROM member WHERE id=? AND pw=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, pw);
		ResultSet rs = pstmt.executeQuery();
		int result = 0;
		if(rs.next()){
			result = rs.getInt(1);
		}
		rs.close();
		pstmt.close();
		conn.close();
		return result==1;
	}
	//이름 표시 select 문
	// showName(int) : member_idx 값을 받아서  이름을 리턴
	// 파라미터 memberIdx : member_idx
	// 리턴 : 파라미터 값에 해당하는 멤버의 이름
	public String showName(String id) throws Exception{
		Connection conn = getConnection();
		String sql = "SELECT name FROM member WHERE id = ?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		
		ResultSet rs = pstmt.executeQuery();
		String result = "";
		if(rs.next()){
			result = rs.getString(1);
		}
		rs.close();
		pstmt.close();
		conn.close();
		
		return result;
	}
	// 포인트 표시 select 문
	// showpoint(int) : showpoint 값을 받아서  이름을 리턴
	// 파라미터 id : id
	// 리턴 : 파라미터 값에 해당하는 포인트
	public String showpoint (String id) throws Exception{
		Connection conn = getConnection();
		String sql = "SELECT name FROM member WHERE id = ?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		
		ResultSet rs = pstmt.executeQuery();
		String result = "";
		if(rs.next()){
			result = rs.getString(1);
		}
		rs.close();
		pstmt.close();
		conn.close();
		
		return result;
	}
	// 포인트 업데이트
	// updatePoint(int, String) : point, id 값을 받아서  이름을 리턴
	// 파라미터 point, id: point, id
	public void updatePoint(int point, String id) throws Exception{
		Connection conn = getConnection();
		String sql = "UPDATE member SET point = point - ? WHERE id=?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, point);
		pstmt.setString(2, id);
		pstmt.executeUpdate();
		pstmt.close();
		conn.close();
	}
	// 포인트 업데이트
	// updatePoint(int, String) : point, id 값을 받아서  이름을 리턴
	// 파라미터 point, id: point, id
	public void addPoint(int point, String id) throws Exception{
		Connection conn = getConnection();
		String sql = "UPDATE member SET point = point + 1000  WHERE id=?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, point);
		pstmt.setString(2, id);
		pstmt.executeUpdate();
		pstmt.close();
		conn.close();
	}
	// 회원정보 업데이트
	// updateMember(int, String) String name, String pw, int point, String id 값을 받아서  이름을 리턴
	// 파라미터 point, id: point, id
	public void updateMember(String name, String pw, int point, String id) throws Exception{
		Connection conn = getConnection();
		String sql = "UPDATE member SET name = ?, pw = ?, point = ?"
					+ "WHERE id = ?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, name);
		pstmt.setString(2, pw);
		pstmt.setInt(3, point);
		pstmt.setString(4, id);
		pstmt.executeUpdate();
		pstmt.close();
		conn.close();
	}
	// 회원정보 삭제
	// updateMember(int, String) String name, String pw, int point, String id 값을 받아서  이름을 리턴
	// 파라미터 point, id: point, id
	public void deleteMember(String name, String pw, int point, String id) throws Exception{
		Connection conn = getConnection();
		String sql = "DELETE FROM member WHERE id = ?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.executeUpdate();
		pstmt.close();
		conn.close();
	}
	// 멤버 보여주기
	// ShowMember() : 멤버 정보 리턴
	public ArrayList<MemberDto> ShowMember () throws Exception{ //모든 DTO를 가지고 오는 메서드
		ArrayList<MemberDto> listRet = new ArrayList<MemberDto>();
		Connection conn = getConnection();
		String sql ="SELECT id, pw, name, point FROM member";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		
		while(rs.next()) {
			String id = rs.getString("id");
			String pw = rs.getString("pw");
			String name = rs.getString("name");
			int point = rs.getInt("point");
			MemberDto dto = new MemberDto(id, pw, name, point);
			listRet.add(dto);
		}
		
		rs.close();
		pstmt.close();
		conn.close();
		return listRet;
	}
	
}
